package bcc266TP1.toy;

import java.util.Random;

public class TP1_sala_aula_2020_01 {
	int[][] memoriaInstrucoes;
	int[] RAM = new int[100];
	
	public static void main(String[] args){
		new TP1_sala_aula_2020_01();
	}
	
	TP1_sala_aula_2020_01(){
		montarRam();
		
		montarInstrucoesProgramaAleatorio();
		
		montarInstrucoesProgramaMultiplicacao(512, 1024);
		System.out.println("Resultado multiplica��o: " + RAM[1]);
		
		montarInstrucoesProgramaDivisao(29, 3);		
		System.out.println("Resultado divis�o: " + RAM[3]);
		
	}
	
		
	void maquinaInterpretada(int[] umaInstrucao){
		int opcode = umaInstrucao[0];
		switch (opcode){
			//levar para RAM
			case 0:{
				RAM[umaInstrucao[2]] = umaInstrucao[1]; 
				break;
			}
			//trazer da RAM
			case 3:{
				umaInstrucao[1]=RAM[umaInstrucao[2]]; 
				break;
			}
			case 1:{
				//somar
				int end1 = umaInstrucao[1];
				int end2 = umaInstrucao[2];
				//buscar na RAM
				int conteudoRam1 = RAM[end1];
				int conteudoRam2 = RAM[end2];
				int soma = conteudoRam1+conteudoRam2;
				//salvando resultado na RAM
				int end3 = umaInstrucao[3];
				RAM[end3] = soma;
				break;
			}
			case 2:{
				//subtrair
				int end1 = umaInstrucao[1];
				int end2 = umaInstrucao[2];
				//buscar na RAM
				int conteudoRam1 = RAM[end1];
				int conteudoRam2 = RAM[end2];
				int sub = conteudoRam1-conteudoRam2;
				//salvando resultado na RAM
				int end3 = umaInstrucao[3];
				RAM[end3] = sub;
				break;
			}
		}
	}
	
	void maquinaTraduzida(){
		//registradores
		int PC =0;
		int opcode = Integer.MAX_VALUE;//maior inteiro poss�vel 2^31 -1 =~ 2bi
		while(opcode!=-1 && PC<memoriaInstrucoes.length){
			int[] umaInstrucao = memoriaInstrucoes[PC];
			
			maquinaInterpretada(umaInstrucao);
			
			PC++;
		}
		
	}

	void montarRam(){
		Random r = new Random();
		for(int i=0; i<100; i++){
			RAM[i] = r.nextInt(1000);
		}		
	}
	
	void montarInstrucoesProgramaAleatorio(){
		//01|22|13|45 => isto � uma instru��o
		//02|33|12|01 => isto � outra instru��o
				
		//0 => salvar na mem�ria
		//3 => trazer da mem�ria
		//1 => opcode => somar
		//2 => opcode => subtrair
		//-1 => halt
		
		memoriaInstrucoes= new int[10][4];
		int[] umaInstrucao=null;
		Random r = new Random();
		for (int i=0; i<9; i++){
			umaInstrucao = new int[4];
			umaInstrucao[0] = r.nextInt(3);//0, 1, 2
			umaInstrucao[1] = r.nextInt(100); //0 ... 99
			umaInstrucao[2] = r.nextInt(100); //0 ... 99
			umaInstrucao[3] = r.nextInt(100); //0 ... 99
			
			memoriaInstrucoes[i] = umaInstrucao;
		}
		
		//inserindo a ultima instrucao do programa que nao faz nada que presta
		umaInstrucao = new int[4];
		umaInstrucao[0] =-1;
		umaInstrucao[1] = -1;
		umaInstrucao[2] = -1;
		umaInstrucao[3] = -1;
		
		memoriaInstrucoes[9] = umaInstrucao;
		
		maquinaTraduzida();
	}
	
	void montarInstrucoesProgramaMultiplicacao(int multiplicando, int multiplicador){
		//0 => salvar na mem�ria
		//3 => trazer da mem�ria
		//1 => opcode => somar
		//2 => opcode => subtrair
		//-1 => halt
		
		// 3 x 4 = 3 + 3 + 3 + 3 
		
		memoriaInstrucoes= new int[multiplicador+3][4];
		
		int[] umaInstrucao=null;		
		umaInstrucao = new int[4];
		umaInstrucao[0] =0;
		umaInstrucao[1] = multiplicando;
		umaInstrucao[2] = 0;
		umaInstrucao[3] = -1;		
		memoriaInstrucoes[0] = umaInstrucao;//vetor de 4 posicoes
		//RAM[0] = 3
		
		
		umaInstrucao = new int[4];
		umaInstrucao[0] =0;
		umaInstrucao[1] = 0;
		umaInstrucao[2] = 1;
		umaInstrucao[3] = -1;		
		memoriaInstrucoes[1] = umaInstrucao;
		//RAM[1] = 12
		
		for(int i=0; i<multiplicador;i++){
			umaInstrucao = new int[4];
			umaInstrucao[0] =1;
			umaInstrucao[1] = 0;
			umaInstrucao[2] = 1;
			umaInstrucao[3] = 1;
			memoriaInstrucoes[i+2] = umaInstrucao;
		}
		
		//inserindo a ultima instrucao do programa que nao faz nada que presta
		umaInstrucao = new int[4];
		umaInstrucao[0] =-1;
		umaInstrucao[1] = -1;
		umaInstrucao[2] = -1;
		umaInstrucao[3] = -1;
		
		memoriaInstrucoes[multiplicador+2] = umaInstrucao;
		
		maquinaTraduzida();
	}
	
	void montarInstrucoesProgramaDivisao(int dividendo, int divisor){
		//0 => salvar na mem�ria
		//3 => trazer da mem�ria
		//1 => opcode => somar
		//2 => opcode => subtrair
		//-1 => halt
		
		// 12 / 3 = (12-3); (9-3); (6-3); (3-3); (0-3) => 4
		// 15 / 4 = (15-4); (11-4); (7-4); (3-4) => 3
		
		//monto um programa apenas para levar os dados para RAM
		memoriaInstrucoes= new int[5][4];
		
		int[] umaInstrucao=null;		
		umaInstrucao = new int[4];
		umaInstrucao[0] =0;
		umaInstrucao[1] = divisor;
		umaInstrucao[2] = 0;
		umaInstrucao[3] = -1;		
		memoriaInstrucoes[0] = umaInstrucao;//vetor de 4 posicoes
		//RAM[0] = divisor
		
		
		umaInstrucao = new int[4];
		umaInstrucao[0] =0;
		umaInstrucao[1] = dividendo;
		umaInstrucao[2] = 1;
		umaInstrucao[3] = -1;		
		memoriaInstrucoes[1] = umaInstrucao;
		//RAM[1] = dividendo
		
		umaInstrucao = new int[4];
		umaInstrucao[0] =0;
		umaInstrucao[1] = 1;
		umaInstrucao[2] = 2;
		umaInstrucao[3] = -1;		
		memoriaInstrucoes[2] = umaInstrucao;
		//RAM[2] = 1
		//representa uma constante de incremento
				
		umaInstrucao = new int[4];
		umaInstrucao[0] =0;
		umaInstrucao[1] = 0;
		umaInstrucao[2] = 3;
		umaInstrucao[3] = -1;		
		memoriaInstrucoes[3] = umaInstrucao;
		//RAM[3] = 0
		//representa quantas subtra��es foram feitas
		//representa o resultado da divis�o
		
		umaInstrucao = new int[4];
		umaInstrucao[0] =-1;
		umaInstrucao[1] = -1;
		umaInstrucao[2] = -1;
		umaInstrucao[3] = -1;		
		memoriaInstrucoes[4] = umaInstrucao;
		
		maquinaTraduzida();
		
		//trazer da RAM[0]
		umaInstrucao = new int[4];
		umaInstrucao[0] =3;
		umaInstrucao[1] = -1;
		umaInstrucao[2] = 0;
		umaInstrucao[3] = -1;		
		maquinaInterpretada(umaInstrucao);
		int ram0 = umaInstrucao[1];
		
		//trazer da RAM[1]
		umaInstrucao = new int[4];
		umaInstrucao[0] =3;
		umaInstrucao[1] = -1;
		umaInstrucao[2] = 1;
		umaInstrucao[3] = -1;		
		maquinaInterpretada(umaInstrucao);
		int ram1 = umaInstrucao[1];
		
		while(ram1>=ram0){
			//subtrair
			umaInstrucao = new int[4];
			umaInstrucao[0] =2;
			umaInstrucao[1] = 1;
			umaInstrucao[2] = 0;
			umaInstrucao[3] = 1;		
			maquinaInterpretada(umaInstrucao);
			
			//somar
			umaInstrucao = new int[4];
			umaInstrucao[0] =1;
			umaInstrucao[1] = 2;
			umaInstrucao[2] = 3;
			umaInstrucao[3] = 3;		
			maquinaInterpretada(umaInstrucao);
			
			//trazer da RAM[0]
			umaInstrucao = new int[4];
			umaInstrucao[0] =3;
			umaInstrucao[1] = -1;
			umaInstrucao[2] = 0;
			umaInstrucao[3] = -1;		
			maquinaInterpretada(umaInstrucao);
			ram0 = umaInstrucao[1];
			
			//trazer da RAM[1]
			umaInstrucao = new int[4];
			umaInstrucao[0] =3;
			umaInstrucao[1] = -1;
			umaInstrucao[2] = 1;
			umaInstrucao[3] = -1;		
			maquinaInterpretada(umaInstrucao);
			ram1 = umaInstrucao[1];
		}
				
	}

}
