
// Criar RAM, vetores de numeros inteiros
// Preencher o vetor com numeros aleatorios 0 - 999

// Montar instrução,
// Criar dentro da instrução, matriz de 10 linhas e 4 colunas (1 opcode 3 Endereços)

// Preencher memoria de instrucao com numeros aleatorios ate a nona linha
// Primeira linha, opcode 3 numeros, 0 salvar na memoria, 1 somar, 2 subtrair.
// Nas outras 3 colunas numeros aleatorioa de 0-99
// Inserir a ultima linha (10° instrução) para finalizar o procedimento.
// 00 => salvar na mem�ria
// 01 => opcode => somar
// 02 => opcode => subtrair
// -1 => halt

//maquina

// Duas varias locais, uma PC = 0 (Registrador, guarda qual e a proxima instrução), outra opcode = maior inteiro possivel.
// Fuciona no while (opcode!= -1), pois a maquina so para quando o opcode for -1
// Chama umaInstrução = memoriaInstrucoes[PC = 0] Ou seja voce pega a linha inteira da memoria de instruçao 
// opcode = umaInstrucao[0] que pode ser valor 0, 1, 2. Como declarado antes
// Depois faz um switch para comprar o valor do opcode, com a funcao que ira executar o que ta no opcode

//Imprimir o 
